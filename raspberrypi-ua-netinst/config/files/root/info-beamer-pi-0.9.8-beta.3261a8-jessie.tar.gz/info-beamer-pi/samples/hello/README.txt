Hello world example. See http://info-beamer.org/doc/ for more information.
