See the documentation at https://info-beamer.com/doc/info-beamer for more information about this example.
