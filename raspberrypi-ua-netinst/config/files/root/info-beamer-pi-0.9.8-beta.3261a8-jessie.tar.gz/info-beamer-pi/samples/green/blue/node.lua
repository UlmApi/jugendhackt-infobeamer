gl.setup(640, 480)

function node.render()
    gl.clear(0, 0, 1, 1) -- blue
end
