gl.setup(100, 800)

function node.render()
    gl.clear(1, 0, 0, 1) -- red
end
