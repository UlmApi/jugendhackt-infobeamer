This folder only contains basic examples. 

More example nodes are available on
https://github.com/dividuum/info-beamer-nodes 
